# CLAUDE_CODE_INSTRUCTIONS — RISC-V SoC Integration

## Project Overview

This repository integrates six independently verified subsystem repositories into a complete RISC-V System-on-Chip. Your job is to wire subsystem RTL together, implement missing glue logic, write testbenches, and ensure everything compiles and simulates under `iverilog -g2012`.

## Subsystem Repos (Read-Only Inputs)

| Repo | Key Top Module | Bus Interface |
|------|---------------|---------------|
| `RISCV_RV32IMC_5stage` | `brv32p_soc` | AXI4-Lite (I-cache + D-cache miss ports) |
| `AXI4_Crossbar` | `axi_xbar_top` | Full AXI4 (N masters, M slaves) |
| `MMU` | `mmu_top` | Custom req/resp (CPU side) + memory read (bus side) |
| `Cache_Controller_MESI` | `cache_top` | CPU req/resp + AXI4-like bus interface + snoop |
| `RISCV_DMA` | `dma_top` | AXI4 master + memory-mapped register slave |
| `RISCV_IOMMU` | `iommu_axi_wrapper` | AXI4 slave (device) + AXI4 master (memory) + register slave |

## RTL Conventions (MUST FOLLOW)

- `always_ff` with synchronous active-high reset `srst` (first branch)
- `snake_case` for all signals, modules, files
- `tb_` prefix for SV testbenches, `test_` prefix for CocoTB
- Author line: `// Brendan Lynskey 2025`
- MIT licence
- Flat directory structure within `rtl/`, `tb/sv/`, `tb/cocotb/`
- Self-checking testbenches with `[PASS]`/`[FAIL]` markers
- Compile with `iverilog -g2012 -Wall`
- Use `$stop` not `$finish`
- `always @(*)` for combinational blocks that read submodule outputs (iverilog compat)

## Address Map

See `rtl/soc_pkg.sv` for the canonical address map. Do NOT change addresses without updating all testbenches.

| Slave | Base | Mask | Description |
|-------|------|------|-------------|
| 0 | `0x0000_0000` | `0x0000_FFFF` | Instruction SRAM (64 KB) |
| 1 | `0x1000_0000` | `0x0001_FFFF` | Data SRAM (128 KB) |
| 2 | `0x2000_0000` | `0x0000_FFFF` | Peripheral bridge |
| 3 | `0x3000_0000` | `0x0000_0FFF` | DMA registers |
| 4 | `0x3000_1000` | `0x0000_0FFF` | IOMMU registers |

## Integration Tasks

### Task 1: Crossbar Configuration
Configure `axi_xbar_top` from `AXI4_Crossbar` with:
- `N_MASTERS = 3` (CPU I, CPU D, DMA)
- `N_SLAVES = 5` (SRAM0, SRAM1, Periph, DMA regs, IOMMU regs)
- Update `axi_xbar_pkg.sv` address map to match `soc_pkg.sv`
- Wire master/slave ports in `riscv_soc_top.sv`

### Task 2: MMU Integration
- Instantiate `mmu_top` between CPU I-port and crossbar Master 0
- Instantiate `mmu_top` between CPU D-port and crossbar Master 1
- Connect `satp` CSR from CPU to MMU
- Wire MMU memory read port through the crossbar (PTW reads go via Master 0/1)
- For initial testing, keep MMU in bypass mode (satp.MODE = 0)

### Task 3: IOMMU Integration
- Instantiate `iommu_axi_wrapper` between DMA AXI master and crossbar Master 2
- Wire IOMMU register interface to crossbar Slave 4
- Connect IOMMU fault interrupt to PLIC

### Task 4: DMA Integration
- Instantiate `dma_top` with AXI master routed through IOMMU
- Wire DMA register slave to crossbar Slave 3
- Connect per-channel DMA interrupts to PLIC IRQ 4–7

### Task 5: Cache Integration (Optional L2)
- `cache_top` from `Cache_Controller_MESI` can sit between MMU output and crossbar
- For single-core, the CPU's L1 caches handle most accesses
- The MESI controller is most useful when adding a second core

### Task 6: Peripheral Integration
- Wire `axi_periph_bridge` to crossbar Slave 2
- Sub-decode peripheral address space to GPIO, UART, Timer
- Connect peripheral interrupts to PLIC

## Testbench Strategy

### Unit TBs (already exist for each subsystem)
Each subsystem repo has its own SV + CocoTB testbenches. Do NOT modify these.

### Integration TBs (this repo)
Write testbenches that verify the glue logic:

1. **tb_axi_sram.sv**: Write/read patterns, byte-lane writes, burst transfers
2. **tb_plic.sv**: Enable/disable IRQs, priority arbitration, threshold
3. **tb_sys_reset.sv**: Async assert, sync deassert, re-assert
4. **tb_riscv_soc_top.sv**: End-to-end: CPU writes SRAM, reads back, DMA transfer, interrupt delivery

### CocoTB Tests
Mirror the SV testbenches in Python for each glue module.

## File Preservation Rules

- NEVER delete or overwrite existing files
- NEVER rename files without explicit instruction
- Merge new content INTO existing READMEs (append, don't replace)
- Each task should be a separate Claude Code session with tightly scoped instructions

## Compilation

```bash
# Glue modules only (no subsystem deps)
iverilog -g2012 -Wall -o sim_sram rtl/axi_sram.sv tb/sv/tb_axi_sram.sv
iverilog -g2012 -Wall -o sim_plic rtl/plic.sv tb/sv/tb_plic.sv
iverilog -g2012 -Wall -o sim_reset rtl/sys_reset.sv tb/sv/tb_sys_reset.sv

# Full SoC (requires subsystem RTL)
iverilog -g2012 -Wall -o sim_soc rtl/*.sv deps/*/rtl/*.sv tb/sv/tb_riscv_soc_top.sv
```
